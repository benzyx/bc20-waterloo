package espada;

import battlecode.common.GameActionException;
import battlecode.common.RobotController;

public class Vaporator extends Unit {

	public Vaporator(RobotController _rc) {
		super(_rc);
	}
	
	@Override
	public void run() throws GameActionException {
	}

}
