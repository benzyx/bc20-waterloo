package escudo;

import battlecode.common.*;

public class Refinery extends Unit {

	public Refinery(RobotController _rc) {
		super(_rc);
		// TODO Auto-generated constructor stub
	}
	
	@Override
	public void run() throws GameActionException {
	}

}
