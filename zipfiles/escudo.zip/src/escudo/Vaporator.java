package escudo;

import battlecode.common.*;

public class Vaporator extends Unit {

	public Vaporator(RobotController _rc) {
		super(_rc);
	}
	
	@Override
	public void run() throws GameActionException {
	}

}
