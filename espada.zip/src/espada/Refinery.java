package espada;

import battlecode.common.GameActionException;
import battlecode.common.RobotController;

public class Refinery extends Unit {

	public Refinery(RobotController _rc) {
		super(_rc);
		// TODO Auto-generated constructor stub
	}
	
	@Override
	public void run() throws GameActionException {
	}

}
